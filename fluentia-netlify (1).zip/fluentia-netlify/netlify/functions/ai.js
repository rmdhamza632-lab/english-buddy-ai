// Netlify Function: keeps your API key secret on the server. Uses the FREE Gemini API by default.
const hits = new Map();
const SYSTEM = "You are the engine of a language-learning app. Follow the formatting instructions exactly. When asked for JSON, return only valid JSON.";

async function ask(prompt) {
  const gk = process.env.GEMINI_API_KEY;      // free: https://aistudio.google.com
  const ak = process.env.ANTHROPIC_API_KEY;   // optional paid alternative
  const fail = (msg, status) => { const e = new Error(msg); e.status = status; throw e; };
  if (gk) {
    const model = process.env.GEMINI_MODEL || "gemini-flash-latest";
    const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": gk },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: "user", parts: [{ text: prompt }] }],
        generationConfig: { maxOutputTokens: 2500, responseMimeType: "application/json" },
      }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) fail((d.error && d.error.message) || "Gemini error " + r.status, r.status);
    const parts = (d.candidates && d.candidates[0] && d.candidates[0].content && d.candidates[0].content.parts) || [];
    const text = parts.map((p) => p.text || "").join("");
    if (!text) fail("Gemini returned an empty reply", 502);
    return text;
  }
  if (ak) {
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ak, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: process.env.CLAUDE_MODEL || "claude-haiku-5-5", max_tokens: 1500, system: SYSTEM, messages: [{ role: "user", content: prompt }] }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) fail((d.error && d.error.message) || "Claude error " + r.status, r.status);
    return (d.content || []).filter((b) => b.type === "text").map((b) => b.text).join("");
  }
  fail("No API key set. Add GEMINI_API_KEY in Netlify environment variables, then redeploy.", 500);
}

function limited(event) {
  const ip = event.headers["x-nf-client-connection-ip"] || event.headers["client-ip"] || "unknown";
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  if (recent.length >= 40) return true;
  recent.push(now);
  hits.set(ip, recent);
  return false;
}

exports.handler = async (event) => {
  const out = (statusCode, obj) => ({ statusCode, headers: { "content-type": "application/json" }, body: JSON.stringify(obj) });

  // Open  /.netlify/functions/ai  in a browser to check the setup.  Add  ?test=1  to run a real test call.
  if (event.httpMethod === "GET") {
    const info = { function: "working", geminiKeySet: !!process.env.GEMINI_API_KEY, claudeKeySet: !!process.env.ANTHROPIC_API_KEY, model: process.env.GEMINI_MODEL || "gemini-flash-latest" };
    if (event.queryStringParameters && event.queryStringParameters.test) {
      if (limited(event)) return out(429, { error: "Too many requests" });
      try { info.testReply = await ask('Reply with exactly {"ok":true}'); } catch (e) { info.testError = e.message; }
    }
    return out(200, info);
  }
  if (event.httpMethod !== "POST") return out(405, { error: "POST only" });

  // Optional: set ALLOWED_ORIGIN (for example https://yourname.netlify.app) so other sites cannot use your key.
  const allowed = process.env.ALLOWED_ORIGIN;
  const origin = event.headers.origin || "";
  if (allowed && origin && origin !== allowed) return out(403, { error: "Origin not allowed" });
  if (limited(event)) return out(429, { error: "Too many requests. Please wait a few minutes." });

  let prompt = "";
  try { prompt = String(JSON.parse(event.body || "{}").prompt || "").slice(0, 8000); } catch (e) {}
  if (!prompt) return out(400, { error: "Missing prompt" });

  try {
    return out(200, { text: await ask(prompt) });
  } catch (e) {
    return out(e.status === 429 ? 429 : e.status === 500 ? 500 : 502, { error: e.message });
  }
};
