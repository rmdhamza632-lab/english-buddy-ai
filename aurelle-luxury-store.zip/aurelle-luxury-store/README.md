# AURELLE — Luxury E-commerce Starter

A mobile-first storefront with product browsing, search, categories, cart, cash-on-delivery checkout, Supabase authentication, and an admin area for products and orders.

## 1. Run locally

Install Node.js (18+), then in this folder:

```bash
npm install
npm run dev
```

Open the local address printed by Vite.

## 2. Connect the database

1. Create a free project at https://supabase.com/
2. Open **SQL Editor** and run all of `supabase/schema.sql`.
3. In Supabase, open **Project Settings → API** and copy the Project URL and anon/public key.
4. Copy `.env.example` to `.env` and fill in the values:

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_SUPABASE_ANON_KEY
```

5. Restart the dev server. Sign up for your store account.
6. In Supabase SQL Editor, promote your account to admin:

```sql
update public.profiles
set role = 'admin'
where email = 'YOUR_LOGIN_EMAIL';
```

Never put the Supabase `service_role` key in frontend code. Only the anon/public key belongs in `.env`.

## 3. Add products

Sign in using the admin account, then open **Admin Studio** by visiting `/` and use the admin access entry you add to the navigation, or add a temporary button in `src/App.jsx` that calls `openAdmin`. The admin UI is included and protected by the `profiles.role = 'admin'` check.

For a quick first run, the storefront displays sample products. Replace these demo products with your own product photos, names, prices and descriptions after connecting Supabase.

## 4. Included / next integrations

- Included: Supabase email/password auth, products table, orders table, admin role checks, cash-on-delivery orders.
- Not yet connected: online card/mobile-wallet payment, shipping courier API, automated SMS/WhatsApp, image upload storage, order tracking page for customers. These need provider accounts and credentials.
- Product image field currently accepts an image URL. A Supabase Storage upload workflow can be added next.

## 5. Branding

The starter uses **AURELLE** as a temporary brand name. Update the wordmark, title, contact details, and colors in `src/App.jsx`, `index.html`, and `src/style.css`.
