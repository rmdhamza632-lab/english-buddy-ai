import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, ArrowUpRight, Search, ShoppingBag, UserRound, Menu, X,
  Plus, Minus, Trash2, Heart, Instagram, ShieldCheck, PackageCheck,
  LayoutDashboard, LogOut, ChevronDown, Sparkles, Truck, CheckCircle2
} from 'lucide-react';
import { isConfigured, supabase } from './supabase';

const demoProducts = [
  {id:'p1',name:'The Heritage Tote',category:'Accessories',price:2850,old_price:3400,description:'A timeless everyday companion with a considered silhouette and thoughtful detailing.',image:'https://images.unsplash.com/photo-154 bags?auto=format&fit=crop&w=900&q=85'.replace('photo-154 bags','photo-1548036328-c9fa89d128fa'),stock:18,featured:true},
  {id:'p2',name:'Amber Glow Serum',category:'Beauty',price:1650,old_price:null,description:'A lightweight daily ritual designed to leave skin feeling refreshed and cared for.',image:'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&w=900&q=85',stock:24,featured:true},
  {id:'p3',name:'The Everyday Timepiece',category:'Watches',price:4250,old_price:4900,description:'Quiet sophistication, clean lines and a versatile finish for every occasion.',image:'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=900&q=85',stock:9,featured:true},
  {id:'p4',name:'Sculpted Ceramic Set',category:'Home',price:2200,old_price:null,description:'A minimal ceramic set that brings warmth and calm to your everyday spaces.',image:'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=900&q=85',stock:12,featured:true},
  {id:'p5',name:'Noir Signature Fragrance',category:'Beauty',price:3100,old_price:null,description:'A distinctive, balanced fragrance made for memorable everyday moments.',image:'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&w=900&q=85',stock:15,featured:false},
  {id:'p6',name:'Linen Ease Shirt',category:'Fashion',price:1950,old_price:2300,description:'An easy wardrobe staple with a relaxed fit and a clean, refined finish.',image:'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=900&q=85',stock:20,featured:false}
];

const money = n => `৳${Number(n || 0).toLocaleString('en-BD')}`;

function App() {
  const [products,setProducts] = useState(demoProducts);
  const [cart,setCart] = useState([]);
  const [page,setPage] = useState('home');
  const [category,setCategory] = useState('All');
  const [search,setSearch] = useState('');
  const [selected,setSelected] = useState(null);
  const [drawer,setDrawer] = useState(false);
  const [user,setUser] = useState(null);
  const [isAdmin,setIsAdmin] = useState(false);
  const [loading,setLoading] = useState(false);
  const [notice,setNotice] = useState('');
  const [orders,setOrders] = useState([]);
  const [authMode,setAuthMode] = useState('login');
  const [authEmail,setAuthEmail] = useState('');
  const [authPassword,setAuthPassword] = useState('');
  const [checkout,setCheckout] = useState({name:'',phone:'',address:'',district:'',note:''});
  const [adminTab,setAdminTab] = useState('products');
  const [newProduct,setNewProduct] = useState({name:'',category:'Fashion',price:'',stock:'',image:'',description:''});

  useEffect(() => {
    if (!isConfigured) return;
    supabase.auth.getSession().then(({data}) => setUser(data.session?.user || null));
    const {data:{subscription}} = supabase.auth.onAuthStateChange((_event,session) => setUser(session?.user || null));
    return () => subscription.unsubscribe();
  }, []);

  useEffect(() => {
    if (!isConfigured) return;
    (async () => {
      const {data} = await supabase.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
      if (data?.length) setProducts(data);
    })();
  }, []);

  useEffect(() => {
    if (!isConfigured || !user) { setIsAdmin(false); return; }
    supabase.from('profiles').select('role').eq('id',user.id).single()
      .then(({data}) => setIsAdmin(data?.role === 'admin'));
  }, [user]);

  useEffect(() => {
    if (!notice) return;
    const t = setTimeout(() => setNotice(''), 3200);
    return () => clearTimeout(t);
  }, [notice]);

  const categories = ['All','Fashion','Accessories','Beauty','Watches','Home'];
  const visibleProducts = useMemo(() => products.filter(p =>
    (category === 'All' || p.category === category) &&
    `${p.name} ${p.category}`.toLowerCase().includes(search.toLowerCase())
  ),[products,category,search]);
  const count = cart.reduce((s,x) => s+x.qty,0);
  const subtotal = cart.reduce((s,x) => s+(Number(x.price)*x.qty),0);

  const addToCart = p => {
    setCart(old => old.some(x=>x.id===p.id) ? old.map(x=>x.id===p.id?{...x,qty:x.qty+1}:x) : [...old,{...p,qty:1}]);
    setNotice('Added to your bag');
  };
  const changeQty = (id,delta) => setCart(old => old.map(x=>x.id===id?{...x,qty:Math.max(1,x.qty+delta)}:x));
  const removeItem = id => setCart(old=>old.filter(x=>x.id!==id));

  async function authenticate(e) {
    e.preventDefault(); setLoading(true);
    if (!isConfigured) { setNotice('Connect Supabase to enable customer accounts.'); setLoading(false); return; }
    const result = authMode==='signup'
      ? await supabase.auth.signUp({email:authEmail,password:authPassword})
      : await supabase.auth.signInWithPassword({email:authEmail,password:authPassword});
    setLoading(false);
    if (result.error) setNotice(result.error.message);
    else { setNotice(authMode==='signup'?'Account created. Check your email if confirmation is enabled.':'Welcome back.'); setPage('home'); }
  }

  async function placeOrder(e) {
    e.preventDefault();
    if (!checkout.name || !checkout.phone || !checkout.address || !checkout.district) { setNotice('Please complete all required delivery details.'); return; }
    if (!cart.length) return;
    if (!isConfigured) { setNotice('Connect Supabase to save real orders. Demo checkout is not submitted.'); return; }
    setLoading(true);
    const payload = {
      user_id:user?.id || null, customer_name:checkout.name, phone:checkout.phone,
      address:checkout.address, district:checkout.district, note:checkout.note,
      total:subtotal, payment_method:'cash_on_delivery', status:'pending',
      items:cart.map(x=>({product_id:x.id,name:x.name,price:x.price,quantity:x.qty,image:x.image}))
    };
    const {error} = await supabase.from('orders').insert(payload);
    setLoading(false);
    if (error) { setNotice(error.message); return; }
    setCart([]); setPage('home'); setNotice('Order received! We will contact you to confirm.');
  }

  async function addProduct(e) {
    e.preventDefault();
    if (!isConfigured || !isAdmin) { setNotice('Admin access is required.'); return; }
    const {error} = await supabase.from('products').insert({
      name:newProduct.name,category:newProduct.category,price:Number(newProduct.price),
      stock:Number(newProduct.stock),image:newProduct.image,description:newProduct.description,active:true
    });
    if (error) setNotice(error.message);
    else {
      const {data} = await supabase.from('products').select('*').eq('active',true).order('created_at',{ascending:false});
      setProducts(data || []); setNewProduct({name:'',category:'Fashion',price:'',stock:'',image:'',description:''}); setNotice('Product published.');
    }
  }

  async function loadOrders() {
    if (!isConfigured || !isAdmin) return;
    const {data,error} = await supabase.from('orders').select('*').order('created_at',{ascending:false});
    if (error) setNotice(error.message); else setOrders(data || []);
  }

  async function updateOrder(id,status) {
    const {error} = await supabase.from('orders').update({status}).eq('id',id);
    if (error) setNotice(error.message);
    else { setOrders(old=>old.map(o=>o.id===id?{...o,status}:o)); setNotice('Order status updated.'); }
  }

  async function deleteProduct(id) {
    const {error} = await supabase.from('products').update({active:false}).eq('id',id);
    if (error) setNotice(error.message);
    else { setProducts(old=>old.filter(p=>p.id!==id)); setNotice('Product removed from store.'); }
  }

  const go = p => { setPage(p); setDrawer(false); window.scrollTo({top:0,behavior:'smooth'}); };
  const openAdmin = () => { go('admin'); loadOrders(); };

  return <div className="app">
    <div className="announcement">A MORE CONSIDERED WAY TO SHOP <span>✦</span> COMPLIMENTARY DELIVERY ON ORDERS OVER ৳5,000</div>
    <header className="header">
      <button className="icon-btn mobile-menu" onClick={()=>setDrawer(!drawer)} aria-label="Menu"><Menu/></button>
      <button className="brand" onClick={()=>go('home')}><span className="brand-mark">A</span><span><b>AURELLE</b><small>CONSIDERED LUXURY</small></span></button>
      <nav className="nav">
        <button onClick={()=>{setCategory('All');go('home')}}>HOME</button>
        <button onClick={()=>{setCategory('Fashion');go('home')}}>FASHION</button>
        <button onClick={()=>{setCategory('Accessories');go('home')}}>ACCESSORIES</button>
        <button onClick={()=>{setCategory('Beauty');go('home')}}>BEAUTY</button>
        <button onClick={()=>go('home')}>OUR STORY</button>
      </nav>
      <div className="header-actions">
        <button className="icon-btn" onClick={()=>document.getElementById('shop')?.scrollIntoView({behavior:'smooth'})} aria-label="Search"><Search/></button>
        <button className="icon-btn" onClick={()=>go('account')} aria-label="Account"><UserRound/></button>
        <button className="bag-btn" onClick={()=>go('cart')} aria-label="Shopping bag"><ShoppingBag/><span>{count}</span></button>
      </div>
    </header>

    {drawer && <div className="mobile-drawer"><button onClick={()=>setDrawer(false)} className="drawer-close"><X/></button>{['Home','Fashion','Accessories','Beauty','Cart','Account'].map(x=><button key={x} onClick={()=>{if(['Fashion','Accessories','Beauty'].includes(x))setCategory(x);go(x==='Cart'?'cart':x==='Account'?'account':'home')}}>{x}</button>)}</div>}

    {page==='home' && <>
      <main>
        <section className="hero">
          <div className="hero-copy"><div className="eyebrow"><span></span> THE ART OF EVERYDAY ELEGANCE</div>
            <h1>Luxury is in<br/><i>the details.</i></h1>
            <p>Discover thoughtfully selected pieces that bring beauty, confidence and meaning to every day.</p>
            <button className="primary-btn" onClick={()=>document.getElementById('shop')?.scrollIntoView({behavior:'smooth'})}>EXPLORE THE COLLECTION <ArrowUpRight size={17}/></button>
            <div className="hero-note"><span>01</span><div><b>CURATED WITH CARE</b><small>Pieces worth keeping.</small></div></div>
          </div>
          <div className="hero-image"><img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1500&q=90" alt="Elegant boutique interior"/><div className="image-stamp">AURELLE<br/><small>EST. 2026</small></div></div>
          <div className="hero-vertical">STYLE • QUALITY • CHARACTER</div>
        </section>
        <section className="trust-strip"><div><Sparkles/><span><b>THOUGHTFULLY CURATED</b><small>Quality in every detail</small></span></div><div><Truck/><span><b>DELIVERY ACROSS BANGLADESH</b><small>Carefully packed, safely sent</small></span></div><div><ShieldCheck/><span><b>SHOP WITH CONFIDENCE</b><small>Personal customer support</small></span></div></section>

        <section className="collection section" id="shop">
          <div className="section-heading"><div><div className="eyebrow">THE AURELLE EDIT</div><h2>Find your <i>signature.</i></h2></div><p>Everyday essentials, elevated.<br/>Explore the collection.</p></div>
          <div className="shop-toolbar"><div className="filters">{categories.map(c=><button key={c} className={category===c?'active':''} onClick={()=>setCategory(c)}>{c}</button>)}</div><label className="search-box"><Search size={17}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search collection"/></label></div>
          <div className="product-grid">{visibleProducts.map((p,i)=><article className="product-card" key={p.id}>
            <button className="product-image" onClick={()=>{setSelected(p);go('product')}}><img src={p.image} alt={p.name}/><span className="product-index">0{i+1}</span><span className="quick-view">QUICK VIEW <ArrowUpRight size={14}/></span></button>
            <div className="product-meta"><span>{p.category}</span><button aria-label="Add to wishlist" onClick={()=>setNotice('Wishlist will be available after account setup.')}><Heart size={17}/></button></div>
            <div className="product-bottom"><h3>{p.name}</h3><div><b>{money(p.price)}</b>{p.old_price&&<del>{money(p.old_price)}</del>}</div></div>
            <button className="add-btn" onClick={()=>addToCart(p)}>ADD TO BAG <Plus size={15}/></button>
          </article>)}</div>
          {!visibleProducts.length&&<div className="empty">No products found. Try another search.</div>}
        </section>

        <section className="editorial"><div className="editorial-image"><img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=1200&q=85" alt="Thoughtfully styled wardrobe"/></div><div className="editorial-copy"><div className="eyebrow">LESS, BUT BETTER</div><h2>Choose pieces<br/>that <i>feel like you.</i></h2><p>We believe great style is personal. Discover a considered collection made to fit naturally into your life.</p><button className="text-link" onClick={()=>{setCategory('Fashion');document.getElementById('shop')?.scrollIntoView({behavior:'smooth'})}}>DISCOVER THE EDIT <ArrowRight size={17}/></button></div></section>

        <section className="newsletter"><div className="eyebrow">A NOTE FROM AURELLE</div><h2>Good things, <i>occasionally.</i></h2><p>New arrivals, thoughtful edits and little moments of inspiration.</p><form onSubmit={e=>{e.preventDefault();setNotice('Thank you for joining our list.');e.target.reset()}}><input type="email" placeholder="Your email address" required/><button>JOIN THE LIST <ArrowRight size={16}/></button></form></section>
      </main>
    </>}

    {page==='product' && selected && <main className="inner-page"><button className="back-link" onClick={()=>go('home')}>← BACK TO COLLECTION</button><div className="product-detail"><img src={selected.image} alt={selected.name}/><div><div className="eyebrow">{selected.category}</div><h1>{selected.name}</h1><h3>{money(selected.price)}</h3><p>{selected.description}</p><p className="muted">In stock: {selected.stock ?? 'Available'}</p><button className="primary-btn" onClick={()=>addToCart(selected)}>ADD TO BAG <ShoppingBag size={17}/></button><div className="detail-note"><Truck/> Delivery available across Bangladesh</div></div></div></main>}

    {page==='cart' && <main className="inner-page"><div className="eyebrow">YOUR SELECTION</div><h1 className="page-title">Shopping <i>bag.</i></h1>{!cart.length?<div className="empty-cart"><ShoppingBag size={38}/><h2>Your bag is waiting.</h2><p>Discover something you'll love.</p><button className="primary-btn" onClick={()=>go('home')}>CONTINUE SHOPPING <ArrowRight/></button></div>:<div className="cart-layout"><div className="cart-items">{cart.map(x=><div className="cart-item" key={x.id}><img src={x.image} alt={x.name}/><div className="cart-info"><span>{x.category}</span><h3>{x.name}</h3><b>{money(x.price)}</b><div className="qty"><button onClick={()=>changeQty(x.id,-1)}><Minus size={14}/></button><span>{x.qty}</span><button onClick={()=>changeQty(x.id,1)}><Plus size={14}/></button></div></div><button className="remove" onClick={()=>removeItem(x.id)}><Trash2 size={17}/></button></div>)}</div><aside className="summary"><h2>Order summary</h2><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Delivery</span><span>Calculated after confirmation</span></div><div className="total"><span>Total</span><b>{money(subtotal)}</b></div><button className="primary-btn full" onClick={()=>go('checkout')}>PROCEED TO CHECKOUT <ArrowRight/></button><small>Cash on delivery available. Our team will confirm your order.</small></aside></div>}</main>}

    {page==='checkout' && <main className="inner-page"><div className="eyebrow">ALMOST YOURS</div><h1 className="page-title">Delivery <i>details.</i></h1><div className="checkout-layout"><form className="form-card" onSubmit={placeOrder}><h2>Where should we send it?</h2><div className="form-grid"><label>Full name *<input required value={checkout.name} onChange={e=>setCheckout({...checkout,name:e.target.value})}/></label><label>Phone number *<input required type="tel" value={checkout.phone} onChange={e=>setCheckout({...checkout,phone:e.target.value})} placeholder="01XXXXXXXXX"/></label><label className="wide">Delivery address *<textarea required value={checkout.address} onChange={e=>setCheckout({...checkout,address:e.target.value})}/></label><label>District *<input required value={checkout.district} onChange={e=>setCheckout({...checkout,district:e.target.value})}/></label><label>Order note (optional)<input value={checkout.note} onChange={e=>setCheckout({...checkout,note:e.target.value})}/></label></div><div className="payment-choice"><b>Payment method</b><span>◉ Cash on Delivery</span><small>Pay when your order arrives.</small></div><button className="primary-btn full" disabled={loading}>{loading?'PLACING ORDER...':'PLACE ORDER'} <ArrowRight/></button></form><aside className="summary"><h2>Your order</h2>{cart.map(x=><div key={x.id}><span>{x.name} × {x.qty}</span><b>{money(x.price*x.qty)}</b></div>)}<div className="total"><span>Total</span><b>{money(subtotal)}</b></div></aside></div></main>}

    {page==='account' && <main className="inner-page narrow"><div className="eyebrow">YOUR AURELLE</div><h1 className="page-title">{user?'Welcome <i>back.</i>':'A place <i>for you.</i>'}</h1>{user?<div className="form-card"><p>Signed in as <b>{user.email}</b></p>{isAdmin&&<button className="primary-btn" onClick={openAdmin}>OPEN ADMIN STUDIO <LayoutDashboard size={16}/></button>}<button className="secondary-btn" style={{marginTop:12}} onClick={async()=>{await supabase.auth.signOut();setUser(null);setNotice('Signed out.')}}><LogOut size={16}/> SIGN OUT</button></div>:<form className="form-card" onSubmit={authenticate}><div className="auth-toggle"><button type="button" className={authMode==='login'?'selected':''} onClick={()=>setAuthMode('login')}>SIGN IN</button><button type="button" className={authMode==='signup'?'selected':''} onClick={()=>setAuthMode('signup')}>CREATE ACCOUNT</button></div><label>Email address<input required type="email" value={authEmail} onChange={e=>setAuthEmail(e.target.value)}/></label><label>Password<input required type="password" minLength="6" value={authPassword} onChange={e=>setAuthPassword(e.target.value)}/></label><button className="primary-btn full" disabled={loading}>{loading?'PLEASE WAIT...':authMode==='login'?'SIGN IN':'CREATE ACCOUNT'} <ArrowRight/></button><small>Customer accounts are securely managed through Supabase Auth.</small></form>}</main>}

    {page==='admin' && <main className="inner-page admin-page"><div className="admin-heading"><div><div className="eyebrow">STORE CONTROL</div><h1 className="page-title">Admin <i>studio.</i></h1></div><span className="admin-status"><span/> ADMIN AREA</span></div>{!user||!isAdmin?<div className="form-card"><h2>Administrator access required</h2><p>Sign in with an account that has been assigned the admin role in Supabase.</p><button className="primary-btn" onClick={()=>go('account')}>GO TO SIGN IN <ArrowRight/></button></div>:<><div className="admin-tabs"><button className={adminTab==='products'?'selected':''} onClick={()=>setAdminTab('products')}>PRODUCTS</button><button className={adminTab==='orders'?'selected':''} onClick={()=>{setAdminTab('orders');loadOrders()}}>ORDERS</button></div>{adminTab==='products'?<div className="admin-grid"><form className="form-card" onSubmit={addProduct}><h2>Add a product</h2><label>Product name<input required value={newProduct.name} onChange={e=>setNewProduct({...newProduct,name:e.target.value})}/></label><label>Category<select value={newProduct.category} onChange={e=>setNewProduct({...newProduct,category:e.target.value})}>{categories.slice(1).map(c=><option>{c}</option>)}</select></label><div className="form-grid"><label>Price (BDT)<input required type="number" min="0" value={newProduct.price} onChange={e=>setNewProduct({...newProduct,price:e.target.value})}/></label><label>Stock<input type="number" min="0" value={newProduct.stock} onChange={e=>setNewProduct({...newProduct,stock:e.target.value})}/></label></div><label>Image URL<input value={newProduct.image} onChange={e=>setNewProduct({...newProduct,image:e.target.value})} placeholder="https://..."/></label><label>Description<textarea value={newProduct.description} onChange={e=>setNewProduct({...newProduct,description:e.target.value})}/></label><button className="primary-btn full">PUBLISH PRODUCT <Plus/></button></form><div className="admin-list"><h2>Live products ({products.length})</h2>{products.map(p=><div className="admin-row" key={p.id}><img src={p.image} alt=""/><span><b>{p.name}</b><small>{money(p.price)} · Stock {p.stock}</small></span><button onClick={()=>deleteProduct(p.id)}><Trash2 size={16}/></button></div>)}</div></div>:<div className="admin-list"><h2>Customer orders ({orders.length})</h2>{orders.map(o=><div className="order-row" key={o.id}><div><b>{o.customer_name}</b><small>{o.phone} · {o.district}</small><small>{(o.items||[]).map(i=>`${i.name} × ${i.quantity}`).join(', ')}</small></div><div><b>{money(o.total)}</b><select value={o.status} onChange={e=>updateOrder(o.id,e.target.value)}><option value="pending">Pending</option><option value="confirmed">Confirmed</option><option value="shipped">Shipped</option><option value="delivered">Delivered</option><option value="cancelled">Cancelled</option></select></div></div>)}</div>}</>}</main>}

    <footer className="footer"><div className="footer-main"><div><div className="brand footer-brand"><span className="brand-mark">A</span><span><b>AURELLE</b><small>CONSIDERED LUXURY</small></span></div><p>Thoughtfully selected pieces.<br/>A more considered way to shop.</p></div><div><b>EXPLORE</b><button onClick={()=>go('home')}>Collection</button><button onClick={()=>go('cart')}>Shopping bag</button><button onClick={()=>go('account')}>My account</button>{isAdmin&&<button onClick={openAdmin}>Admin studio</button>}</div><div><b>NEED HELP?</b><span>Customer care</span><span>Delivery & returns</span><span>Contact: add your number</span></div><div><b>FOLLOW OUR JOURNEY</b><div className="social"><Instagram/><span>@aurelle.store</span></div></div></div><div className="footer-bottom"><span>© 2026 AURELLE. ALL RIGHTS RESERVED.</span><span>MADE WITH INTENTION.</span></div></footer>
    <div className="mobile-bottom"><button className={page==='home'?'on':''} onClick={()=>go('home')}>HOME</button><button className={page==='cart'?'on':''} onClick={()=>go('cart')}>BAG ({count})</button><button className={page==='account'?'on':''} onClick={()=>go('account')}>ACCOUNT</button></div>
    {notice&&<div className="toast"><CheckCircle2 size={17}/>{notice}<button onClick={()=>setNotice('')}><X size={15}/></button></div>}
    {!isConfigured&&<div className="setup-banner">PREVIEW MODE · Connect Supabase to activate accounts, orders and admin tools.</div>}
  </div>;
}

export default App;
